"use client"

import { useState } from "react"
import { ArrowLeft, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export default function BankingApp() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="flex min-h-screen flex-col items-center bg-black text-white">
      <div className="relative w-full max-w-md mx-auto h-screen overflow-hidden">
        {/* Phone frame */}
        <div className="relative h-full w-full overflow-hidden rounded-[40px] border-[14px] border-[#111] bg-black">
          {/* Status bar */}
          <div className="flex justify-between items-center px-5 py-2 bg-black">
            <div></div>
            <div className="flex items-center gap-1">
              <div className="h-2.5 w-0.5 bg-white rounded-full"></div>
              <div className="h-3 w-0.5 bg-white rounded-full"></div>
              <div className="h-3.5 w-0.5 bg-white rounded-full"></div>
              <div className="h-4 w-0.5 bg-white rounded-full"></div>
            </div>
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 bg-white rounded-full"></div>
              <div className="h-2 w-2 border border-white rounded-sm"></div>
            </div>
          </div>

          {/* Welcome header */}
          <div className="bg-gray-200 text-black py-8 px-4 text-center">
            <button className="absolute left-4 top-4">
              <ArrowLeft className="h-5 w-5" />
            </button>
            <h1 className="text-2xl font-bold">WELCOME</h1>
            <h1 className="text-2xl font-bold">TO</h1>
            <h1 className="text-2xl font-bold">ABC BANK</h1>
          </div>

          {/* Search bar */}
          <div className="px-4 py-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
              <Input
                type="text"
                placeholder="E.g. Need a bank statement"
                className="pl-9 bg-gray-200 border-none text-gray-700"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Menu section */}
          <div className="px-4 py-2">
            <h2 className="text-xl font-bold mb-4">MENU</h2>
            <div className="space-y-3 overflow-y-auto pr-2">
              <Button
                variant="outline"
                className="w-full bg-gray-200 text-black hover:bg-gray-300 rounded-full py-6 font-bold"
              >
                BANK STATEMENT
              </Button>
              <Button
                variant="outline"
                className="w-full bg-gray-200 text-black hover:bg-gray-300 rounded-full py-6 font-bold"
              >
                CREDIT CARD
              </Button>
              <Button
                variant="outline"
                className="w-full bg-gray-200 text-black hover:bg-gray-300 rounded-full py-6 font-bold"
              >
                DEBIT CARD
              </Button>
              <Button
                variant="outline"
                className="w-full bg-gray-200 text-black hover:bg-gray-300 rounded-full py-6 font-bold"
              >
                OFFERS
              </Button>
              <Button
                variant="outline"
                className="w-full bg-gray-200 text-black hover:bg-gray-300 rounded-full py-6 font-bold"
              >
                CHAT WITH AI AGENT
              </Button>
            </div>
          </div>

          {/* Performance notice */}
          <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-80 text-white text-xs p-2 flex justify-between items-center">
            <span>Improve performance by enabling hardware acceleration</span>
            <div className="flex items-center gap-2">
              <span className="underline">Learn more</span>
              <button className="h-4 w-4 flex items-center justify-center border border-white rounded-sm">×</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

